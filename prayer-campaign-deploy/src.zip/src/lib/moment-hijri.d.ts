declare module "moment-hijri" {
  import moment from "moment";
  export = moment;
}